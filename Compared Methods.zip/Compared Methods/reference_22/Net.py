import torch.nn as nn
import torch.nn.functional as F
import config


class Net(nn.Module):
    def __init__(self, num_classes=config.class_num):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(3, 7, 5)
        self.pool1 = nn.MaxPool2d(2)
        self.conv2 = nn.Conv2d(7, 12, 2)
        self.fc = nn.Linear(588, num_classes)

    def forward(self, x):
        x = F.relu(self.conv1(x), inplace=True)
        x = self.pool1(x)
        x = F.relu(self.conv2(x), inplace=True)
        x = x.view(x.size(0), -1)
        x = F.softmax(self.fc(x), dim=1)
        return x


if __name__ == '__main__':
    model = Net()
    print(model)

