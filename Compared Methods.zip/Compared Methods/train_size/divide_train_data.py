import os
import random
import shutil


if __name__ == '__main__':
    train_data_dir = r'D:\datasets\malaria\1_multistage_malaria_classification\train'
    train_data_dir_new = r'D:\datasets\malaria\1_multistage_malaria_classification\train_20'  # 20%,40%,60%,80%
    if not os.path.exists(train_data_dir_new):
        os.makedirs(train_data_dir_new)
    for the_dir in os.listdir(train_data_dir):
        class_dir_new = os.path.join(train_data_dir_new, the_dir)
        if not os.path.exists(class_dir_new):
            os.makedirs(class_dir_new)
        class_dir = os.path.join(train_data_dir, the_dir)
        path_list = []
        for image_name in os.listdir(class_dir):
            image_path = os.path.join(class_dir, image_name)
            path_list.append(image_path)
        path_list_new = random.sample(path_list, int(len(path_list) * 0.2))  # 0.2,0.4,0.6,0.8
        for image_path in path_list_new:
            image_name = image_path.split('\\')[-1]
            shutil.copy(image_path, os.path.join(class_dir_new, image_name))
























