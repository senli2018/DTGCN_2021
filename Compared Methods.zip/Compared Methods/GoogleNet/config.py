import os
import torchvision.transforms as transforms

# dir
model_dir = 'Model_and_Log'
net_dir = 'ResNet'
model_name = 'MicroData'
model_path = 'model.pkl'

best_epoch = 'best_epoch'

class_num = 6

# resnet
train_batch_size = 70
test_batch_size = 70


# GCN_model
features_dim_num = 2048
GCN_hidderlayer_dim_num = 512


# train_GCN
train_dataset_path = r'D:\datasets\malaria\1_multistage_malaria_classification\train'
test_dataset_path = r'D:\datasets\malaria\1_multistage_malaria_classification\test'

epochs = 500
k = 10

train_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

test_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])











