import torch.nn as nn
import torch.nn.functional as F
import config


class Net(nn.Module):
    def __init__(self, num_classes=config.class_num):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(3, 16, 3)
        self.conv2 = nn.Conv2d(16, 32, 4)
        self.pool1 = nn.MaxPool2d(2)
        self.conv3 = nn.Conv2d(32, 64, 3)
        self.conv4 = nn.Conv2d(64, 128, 3)
        self.pool2 = nn.MaxPool2d(2)
        self.conv5 = nn.Conv2d(128, 256, 2)
        self.pool3 = nn.AvgPool2d(3)
        self.fc = nn.Linear(16384, num_classes)

        self.relu = nn.ReLU(inplace=True)
        self.drop = nn.Dropout(0.2)

    def forward(self, x):
        x = self.drop(self.relu(self.conv1(x)))
        x = self.relu(self.conv2(x))
        x = self.drop(self.pool1(x))
        x = self.drop(self.relu(self.conv3(x)))
        x = self.relu(self.conv4(x))
        x = self.drop(self.pool2(x))
        x = self.relu(self.conv5(x))
        x = self.drop(self.pool3(x))
        x = x.view(x.size(0), -1)
        x = F.softmax(self.fc(x), dim=1)
        return x


if __name__ == '__main__':
    model = Net()
    print(model)

