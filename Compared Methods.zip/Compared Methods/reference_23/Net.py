import torch.nn as nn
import torch.nn.functional as F
import config


class Net(nn.Module):
    def __init__(self, num_classes=config.class_num):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(3, 32, 3)
        self.pool1 = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(32, 32, 3)
        self.pool2 = nn.MaxPool2d(2, 2)
        self.conv3 = nn.Conv2d(32, 64, 3)
        self.pool3 = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(10*10*64, 10*10*64)
        self.fc2 = nn.Linear(10*10*64, 10*10*2)
        self.fc3 = nn.Linear(10*10*2, num_classes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.relu(self.conv1(x))
        x = self.pool1(x)
        x = self.relu(self.conv2(x))
        x = self.pool2(x)
        x = self.relu(self.conv3(x))
        x = self.pool3(x)
        x = x.view(x.size(0), -1)
        x = self.fc1(x)
        x = self.fc2(x)
        x = F.softmax(self.fc3(x), dim=1)
        return x


if __name__ == '__main__':
    model = Net()
    print(model)

