import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import torchvision.datasets as dataset
import numpy as np
import os
import time
from sklearn.svm import SVC

from VGGNet import Net
import config
from torchsampler.imbalanced import ImbalancedDatasetSampler


def train():
    train_dataset = dataset.ImageFolder(config.train_dataset_path, transform=config.train_transform)
    train_dataloader = DataLoader(train_dataset, config.train_batch_size, sampler=ImbalancedDatasetSampler(train_dataset))
    test_dataset = dataset.ImageFolder(config.test_dataset_path, transform=config.test_transform)
    test_dataloader = DataLoader(test_dataset, config.test_batch_size, shuffle=False)

    # define GPU
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # define model
    if os.path.exists(config.model_path) is not True:
        net = Net().to(device)
    else:
        # net = torch.load(config.model_path)
        net = Net().to(device)

    cross_loss = nn.CrossEntropyLoss()
    optimizer = optim.Adam(net.parameters(), lr=1e-5, weight_decay=5e-4)

    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=50, gamma=0.1)

    best_acc = 0.
    for epoch in range(config.epochs):
        net.train()
        sum_loss = 0.
        correct = 0.
        total = 0.
        length = len(train_dataloader)
        since = time.time()
        feature_list = []
        labels_true = []

        for i, data in enumerate(train_dataloader, 0):
            inputs, labels = data
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()

            outputs, features = net(inputs)
            feature_list.append(features)
            for label in labels_true:
                labels_true.append(label.cpu().data.numpy())

            loss1 = cross_loss(outputs, labels)
            loss = loss1

            loss.backward()
            torch.cuda.empty_cache()
            optimizer.step()
            sum_loss += loss.item()

            _, pre = torch.max(outputs.data, 1)

            total += outputs.size(0)
            correct += torch.sum(pre == labels.data)
            train_acc = correct / total

            print('[epoch:%d, iter:%d] Loss: %f | Acc: %f | Time: %f'
                  % (epoch + 1, (i + 1 + epoch * length), sum_loss/(i + 1), train_acc, time.time() - since))

        scheduler.step()
        train_features = np.concatenate(feature_list, 1)
        labels_true = np.array(labels_true)

        # start to test
        if epoch % 1 == 0:
            print("start to test:")
            with torch.no_grad():
                correct = 0.
                total = 0.
                for i, data in enumerate(test_dataloader):
                    net.eval()
                    inputs_test, labels_test = data
                    inputs_test, labels_test = inputs_test.to(device), labels_test.to(device)
                    outputs_test, features = net(inputs_test)
                    SVMClassifier = SVC(kernel='poly', degree=3, gamma="auto")
                    SVMClassifier.fit(train_features, labels_true)
                    result = SVMClassifier.predict(features)
                    # present_max, pred = torch.max(outputs.data, 1)
                    _, pred = torch.max(outputs_test.data, 1)

                    total += labels_test.size(0)
                    correct += torch.sum(torch.tensor(result).to(device) == labels_test.data)
                test_acc = correct / total
                print('test_acc:', test_acc, '| time', time.time() - since)


if __name__ == '__main__':
    train()
